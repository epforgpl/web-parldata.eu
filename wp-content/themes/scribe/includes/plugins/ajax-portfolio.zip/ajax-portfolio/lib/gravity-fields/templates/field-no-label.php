<div<?php $this->field_atts() ?>>
	<div class="field-wrap">
		<?php $this->display_input(); ?>

		<?php if($this->description): ?>
		<p class="description"><?php echo $this->description ?></p>
		<?php endif; ?>
	</div>
	<div class="cl">&nbsp;</div>
</div>