<?php
/**
 * Miscellaneous functions
 */
include_once( 'misc.php' );

/**
 * Registers all scripts that will be available
 * throughout the plugin
 */
include_once( 'scripts.php' );